[![Build Status](https://travis-ci.org/EduardoKrausME/moodle-theme_boost_magnific.svg?branch=master)](https://travis-ci.org/EduardoKrausME/moodle-theme_boost_magnific)

Boost Magnific é uma melhoria do tema boost padrão do Moodle.

## instalando

#### No Linux via GIT

Vá na pasta [pasta_instalacao_moodle]/theme e execute:

```
git clone https://github.com/EduardoKrausME/moodle-theme_boost_magnific boost_magnific
```

Após vá em _Administração do site_ >> _Avisos_ e instale o tema Boost Magnific

#### Via instalador de plugins do Moodle

Baixe o arquivo boost_magnific.zip em https://github.com/EduardoKrausME/moodle-theme_boost_magnific/releases/latest e envie ele no instalador de plugins do Moodle

Após vá em _Administração do site_ >> _Avisos_ e instale o Boost Magnific

#### Por FTP

Baixe o arquivo boost_magnific.zip em https://github.com/EduardoKrausME/moodle-theme_boost_magnific/releases/latest descompacte e envie todos os arquivos baixados para a pasta ``[pasta_instalacao_moodle]/theme/``

Após vá em _Administração do site_ >> _Avisos_ e instale o Boost Magnific 