<?php
// This file was auto-generated from sdk-root/src/data/inspector/2016-02-16/paginators-1.json
return [ 'pagination' => [],];
