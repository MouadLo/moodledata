<?php
// This file was auto-generated from sdk-root/src/data/xray/2016-04-12/paginators-1.json
return [ 'pagination' => [],];
