<?php
// This file was auto-generated from sdk-root/src/data/workdocs/2016-05-01/paginators-1.json
return [ 'pagination' => [ 'DescribeDocumentVersions' => [ 'input_token' => 'Marker', 'limit_key' => 'Limit', 'output_token' => 'Marker', 'result_key' => 'DocumentVersions', ], 'DescribeFolderContents' => [ 'input_token' => 'Marker', 'limit_key' => 'Limit', 'output_token' => 'Marker', 'result_key' => [ 'Folders', 'Documents', ], ], 'DescribeUsers' => [ 'input_token' => 'Marker', 'limit_key' => 'Limit', 'output_token' => 'Marker', 'result_key' => 'Users', ], ],];
